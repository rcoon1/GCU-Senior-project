package com.DPE;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;


@SpringBootApplication
public class DPEApplication {

	public static void main(String[] args) {
		SpringApplication.run(DPEApplication.class, args);
	}
}
