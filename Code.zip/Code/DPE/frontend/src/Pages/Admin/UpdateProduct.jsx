import React from 'react'

const UpdateProduct = () => {
    return (
        <div>UpdateProduct</div>
    )
}

export default UpdateProduct